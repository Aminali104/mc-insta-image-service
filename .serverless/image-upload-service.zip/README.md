# Image Upload Service

This project is a serverless application built using AWS Lambda, API Gateway, S3, and DynamoDB. It allows you to upload, list, view, and delete images stored in an S3 bucket. The metadata for each image is stored in DynamoDB.

## Requirements

- AWS CLI
- LocalStack (for local development)
- Serverless Framework (for deployment)

## Setup and Running Locally

### 1. Install dependencies

```bash
pip install -r requirements.txt
